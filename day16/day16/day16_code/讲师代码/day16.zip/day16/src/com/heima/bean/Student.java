package com.heima.bean;

public class Student extends Person {

	public Student() {
	}

	public Student(String name, int age) {
		super(name, age);

	}

}
