package com.heima.bean;

public class Worker extends Person {

	public Worker() {
	}

	public Worker(String name, int age) {
		super(name, age);

	}

}
