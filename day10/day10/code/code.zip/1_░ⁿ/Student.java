package com.xxx;
import com.baidu.Person;
public class Student extends Person {
	public Student(){}

	public Student(String name,int age) {
		super(name,age);
	}

	public void method() {
		print();
	}
}
