package com.heima.eclipse;

public class HelloWorld {
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("HelloWorld!!");
		int num = 10;
		System.out.println(num);
	}

	private int num1 = 10;
	
	int nu2 = 20;
	
	protected int num3 = 30;
	
	public int num4 = 40;
	
	private void method1() {

		System.out.println(num1);
	}
	
	void method2(){
		System.out.println(num1);
	}
	
	protected void method3() {

		System.out.println(num1);
	}
	
	public static void method4(){
		
	}

	public static final void method5(){
		
	}
	
	
	
	
	
	
	
	

}
