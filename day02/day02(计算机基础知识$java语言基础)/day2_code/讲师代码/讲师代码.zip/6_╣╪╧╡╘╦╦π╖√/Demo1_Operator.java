class Demo1_Operator {
	public static void main(String[] args) {
		//��ϵ�����
		//==,!=,>,>=,<,<= 
		System.out.println(4 == 3);
		System.out.println(4 != 3);
		System.out.println(4 > 4);
		System.out.println(4 >= 4);
		System.out.println(4 < 3);
		System.out.println(4 <= 3);
	}
}
