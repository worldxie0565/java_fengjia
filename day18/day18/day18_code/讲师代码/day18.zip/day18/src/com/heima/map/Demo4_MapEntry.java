package com.heima.map;

public class Demo4_MapEntry {

	/**
	 * @param args
	 * ����һ��Map.Entry
	 */
	public static void main(String[] args) {

	}

}

interface Inter {
	interface Inter2 {
		public void show();
	}
}

class Demo implements Inter.Inter2 {

	@Override
	public void show() {
	}
	
}