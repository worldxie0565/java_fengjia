package com.heima.bean;

public class BaseStudent extends Student {

	public BaseStudent() {
	}

	public BaseStudent(String name, int age) {
		super(name, age);

	}

}
